package com.springboot.service;

import com.springboot.exception.ResourceNotFoundException;
import com.springboot.model.Employee;
import com.springboot.repository.EmployeeRepository;
import com.springboot.service.impl.EmployeeServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ServiceTests {

    @Mock
    private EmployeeRepository employeeRepository;
    @InjectMocks
    private EmployeeServiceImpl employeeService;

    private Employee employee;


    @BeforeEach
    public void setUp() {
        employee = Employee.builder()
                .firstName("john")
                .lastName("doe")
                .email("test@gmail.com")
                .build();
    }

    @Test
    public void givenEmployee_whenSaveEmployee_thenReturnEmployee() {
        //mock of employee repository
        given(employeeRepository.findByEmail(employee.getEmail()))
                .willReturn(Optional.empty());
        given(employeeRepository.save(employee)).willReturn(employee);
        Employee employee1 = employeeService.saveEmployee(employee);
        Assertions.assertTrue(employee1 != null);
    }

    @Test
    public void givenEmployee_whenSaveEmployeeWithExistingEmail_thenThrowException() {
        //mock of employee repository
        given(employeeRepository.findByEmail(employee.getEmail()))
                .willReturn(Optional.of(employee));

        Assertions.assertThrows(ResourceNotFoundException.class, () -> {
            employeeService.saveEmployee(employee);
        });
        verify(employeeRepository, never()).save(any(Employee.class));
    }

    @Test
    public void givenEmployee_whenSaveUpdateEmployee_thenReturnEmployee() {
        //mock of employee repository
        given(employeeRepository.save(employee))
                .willReturn(employee);
        employee.setEmail("google@gmail.com");
        Employee updatedEmployee = employeeService.updateEmployee(employee);
        Assertions.assertEquals(updatedEmployee.getEmail(), employee.getEmail());
    }

    @Test
    public void givenEmployee_whenDeleteEmployee_thenReturnNothing() {
        long id = 1L;
        willDoNothing().given(employeeRepository).deleteById(id);
        employeeService.deleteEmployee(id);
        verify(employeeRepository, times(1)).deleteById(id);
    }
}
