package com.springboot.repository;

import com.springboot.model.Employee;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

@DataJpaTest // only your repository and entity classes
public class RepositoryTests {

    @Autowired
    private EmployeeRepository employeeRepository;

    private Employee employee;

    @BeforeEach
    public void setUp() {
        employee = Employee.builder()
                .firstName("john")
                .lastName("doe")
                .email("test@gmail.com")
                .build();
    }

    //given when then
    @DisplayName("Test for save employee")
    @Test
    public void givenEmployeeObject_whenSave_thenReturnSavedEmployee() {
        //given
        //when
        Employee savedEmployee = employeeRepository.save(employee);
        //then
        Assertions.assertTrue(savedEmployee != null);
        Assertions.assertTrue(savedEmployee.getId() > 0);
    }

    @DisplayName("Test for get all employees")
    @Test
    public void givenEmployeesList_whenFindAll_thenReturnEmployeesList() {
        //given
        employeeRepository.save(employee);
        Employee employee = Employee.builder()
                .firstName("john")
                .lastName("doe")
                .email("test@gmail.com")
                .build();
        employeeRepository.save(employee);
        //when
        List<Employee> employees = employeeRepository.findAll();
        //then
        Assertions.assertTrue(employees != null);
        Assertions.assertTrue(employees.size() > 0);
    }


    @DisplayName("Test for get employee by id employees")
    @Test
    public void givenEmployee_whenFindById_thenReturnEmployee() {
        employeeRepository.save(employee);
        Employee employeeDb = employeeRepository.findById(employee.getId()).get();
        Assertions.assertTrue(employeeDb != null);
    }

    @DisplayName("Test for get employee by name")
    @Test
    public void givenEmployee_whenFindByJPQL_thenReturnEmployee() {
        employeeRepository.save(employee);
        Employee employeeDb = employeeRepository.findByJPQL(employee.getFirstName(), employee.getLastName());
        Assertions.assertTrue(employeeDb != null);
    }
}
